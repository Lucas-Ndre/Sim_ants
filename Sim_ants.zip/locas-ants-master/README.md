# Ants

**To quick run it:**
- Execute Sim_ants.exe


**To play with the source project:** 
- Download or clone.
- install love2d: https://love2d.org/
- install ZeroBrane Studio: https://studio.zerobrane.com/download?not-this-time 
- Open the Main.Lua with ZeroBrane.
- On ZeroBrane go to menu : Project -> Lua Interpreter -> LÖVE.
- And execute with F6 :) ready!

