vec2d.lua:  library for 2d vectors. Manually copied from https://github.com/piXelicidio/lua-vec2d
